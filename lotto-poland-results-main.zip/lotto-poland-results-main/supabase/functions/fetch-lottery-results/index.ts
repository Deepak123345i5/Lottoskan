
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const magayoApiKey = Deno.env.get('MAGAYO_API_KEY')!
const supabase = createClient(supabaseUrl, supabaseKey)

async function fetchMagayoResults(gameType: string) {
  const response = await fetch(`https://api.magayo.com/poland/${gameType}/results?api_key=${magayoApiKey}`, {
    method: 'GET',
  })
  if (!response.ok) {
    throw new Error(`Failed to fetch ${gameType} results: ${response.statusText}`)
  }
  return response.json()
}

function formatMagayoResult(result: any, gameType: string) {
  const nextDraw = new Date()
  
  switch(gameType) {
    case 'eurojackpot':
      nextDraw.setDate(nextDraw.getDate() + (5 - nextDraw.getDay())) // Next Friday
      break;
    case 'multi_multi':
      nextDraw.setHours(14, 0, 0, 0) // Today at 14:00
      if (nextDraw < new Date()) {
        nextDraw.setHours(22, 0, 0, 0) // Today at 22:00
        if (nextDraw < new Date()) {
          nextDraw.setDate(nextDraw.getDate() + 1)
          nextDraw.setHours(14, 0, 0, 0)
        }
      }
      break;
    case 'mini_lotto':
      // Daily at 22:00
      nextDraw.setHours(22, 0, 0, 0)
      if (nextDraw < new Date()) {
        nextDraw.setDate(nextDraw.getDate() + 1)
      }
      break;
    case 'kaskada':
      // Four times daily at 09:40, 14:40, 19:40 and 21:40
      const hours = [9, 14, 19, 21]
      let found = false
      for (const hour of hours) {
        nextDraw.setHours(hour, 40, 0, 0)
        if (nextDraw > new Date()) {
          found = true
          break
        }
      }
      if (!found) {
        nextDraw.setDate(nextDraw.getDate() + 1)
        nextDraw.setHours(9, 40, 0, 0)
      }
      break;
    case 'szybkie_600':
      // Every 4 minutes
      nextDraw.setMinutes(nextDraw.getMinutes() + 4 - (nextDraw.getMinutes() % 4), 0, 0)
      break;
    case 'ekstra_pensja':
    case 'ekstra_premia':
      // Daily at 22:00
      nextDraw.setHours(22, 0, 0, 0)
      if (nextDraw < new Date()) {
        nextDraw.setDate(nextDraw.getDate() + 1)
      }
      break;
    default:
      // Lotto - Tuesday, Thursday, Saturday at 22:00
      const day = nextDraw.getDay()
      if (day === 2 || day === 4 || day === 6) {
        nextDraw.setHours(22, 0, 0, 0)
        if (nextDraw < new Date()) {
          nextDraw.setDate(nextDraw.getDate() + (day === 6 ? 3 : 2))
        }
      } else {
        nextDraw.setDate(nextDraw.getDate() + ((day < 2 ? 2 : day < 4 ? 4 : day < 6 ? 6 : 9) - day))
        nextDraw.setHours(22, 0, 0, 0)
      }
  }

  return {
    game_type: gameType,
    draw_date: new Date(result.draw_date),
    numbers: result.winning_numbers.map(Number),
    extra_numbers: result.extra_numbers ? result.extra_numbers.map(Number) : [],
    prize_amount: result.prize_amount || "0.00",
    next_draw: nextDraw,
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const games = [
      'lotto',
      'multi_multi',
      'eurojackpot',
      'mini_lotto',
      'kaskada',
      'szybkie_600',
      'ekstra_pensja',
      'ekstra_premia'
    ]
    const results = []

    for (const game of games) {
      try {
        const magayoResult = await fetchMagayoResults(game)
        const formattedResult = formatMagayoResult(magayoResult, game)
        
        // Update or insert the result in the database
        const { error: upsertError } = await supabase
          .from('lottery_results')
          .upsert([formattedResult], {
            onConflict: 'game_type',
            ignoreDuplicates: false
          })
        
        if (upsertError) throw upsertError
        results.push(formattedResult)
      } catch (error) {
        console.error(`Error fetching ${game} results:`, error)
        // If API fails, get the latest result from database
        const { data: dbResult, error: dbError } = await supabase
          .from('lottery_results')
          .select('*')
          .eq('game_type', game)
          .limit(1)
          .single()
        
        if (!dbError && dbResult) {
          results.push(dbResult)
        }
      }
    }

    return new Response(
      JSON.stringify({ results }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )
  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      },
    )
  }
})

