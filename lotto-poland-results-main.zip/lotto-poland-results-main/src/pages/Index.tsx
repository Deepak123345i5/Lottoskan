
import { useEffect, useState } from "react";
import { GameCard } from "@/components/GameCard";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";

const fetchLotteryResults = async () => {
  const { data } = await supabase.functions.invoke('fetch-lottery-results')
  return data.results
}

const formatNextDraw = (nextDraw: string) => {
  const date = new Date(nextDraw)
  const isToday = new Date().toDateString() === date.toDateString()
  const time = date.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' })
  return isToday ? `dziś o ${time}` : date.toLocaleDateString('pl-PL')
}

const getGameDetails = (gameType: string) => {
  switch(gameType) {
    case 'lotto':
      return {
        title: 'Lotto',
        description: "Gra liczbowa, w której należy wytypować 6 z 49 liczb. Losowania odbywają się we wtorki, czwartki i soboty.",
        drawTimes: "Wt, Czw, Sob o 22:00",
        price: "3 zł"
      };
    case 'multi_multi':
      return {
        title: 'Multi Multi',
        description: "Tutaj wszystko zależy od Ciebie. Wytypuj od 1 do 10 liczb ze zbioru 80. Im więcej liczb typujesz, tym większa może być Twoja wygrana.",
        drawTimes: "Codziennie o 14:00 i 22:00",
        price: "2,50 zł"
      };
    case 'eurojackpot':
      return {
        title: 'Eurojackpot',
        description: "Emocjonująca gra, która przyspiesza bicie serca milionów ludzi na całym kontynencie. Wytypuj 5 z 50 liczb oraz 2 z 12 liczb.",
        drawTimes: "We wtorki i piątki 20:00-21:00",
        price: "12,50 zł"
      };
    case 'mini_lotto':
      return {
        title: 'Mini Lotto',
        description: "Codzienna szansa na wygraną. Wytypuj 5 z 42 liczb. Proste zasady i atrakcyjne wygrane.",
        drawTimes: "Codziennie o 22:00",
        price: "1,50 zł"
      };
    case 'kaskada':
      return {
        title: 'Kaskada',
        description: "Wybierz 12 z 24 liczb. Możesz wygrać nawet jeśli trafisz 0 liczb! Cztery losowania dziennie.",
        drawTimes: "Codziennie o 9:40, 14:40, 19:40 i 21:40",
        price: "2 zł"
      };
    case 'szybkie_600':
      return {
        title: 'Szybkie 600',
        description: "Gra dla niecierpliwych! Typujesz 6 liczb z 32. Losowania co 4 minuty!",
        drawTimes: "Co 4 minuty",
        price: "2 zł"
      };
    case 'ekstra_pensja':
      return {
        title: 'Ekstra Pensja',
        description: "Gwarantowana wypłata przez 20 lat! Wybierz 5 liczb z 35 oraz 1 z 4.",
        drawTimes: "Codziennie o 22:00",
        price: "5 zł"
      };
    case 'ekstra_premia':
      return {
        title: 'Ekstra Premia',
        description: "Dodatkowa szansa na wygraną! Wybierz 5 liczb z 35 oraz 1 z 4.",
        drawTimes: "Codziennie o 22:00",
        price: "5 zł"
      };
    default:
      return {
        title: gameType,
        description: "Szczegóły wkrótce",
        drawTimes: "Sprawdź szczegóły",
        price: "---"
      };
  }
};

const Index = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);

  const { data: results, refetch } = useQuery({
    queryKey: ['lottery-results'],
    queryFn: fetchLotteryResults,
    refetchInterval: 60000, // Refresh every minute
  });

  useEffect(() => {
    const channel = supabase
      .channel('schema-db-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'lottery_results'
        },
        (payload) => {
          toast({
            title: "Nowe wyniki",
            description: "Wyniki zostały zaktualizowane.",
          });
          refetch(); // Refresh data when we receive an update
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [toast, refetch]);

  useEffect(() => {
    if (results) {
      setIsLoading(false);
    }
  }, [results]);

  const games = results?.map(result => {
    const gameDetails = getGameDetails(result.game_type);
    return {
      ...gameDetails,
      nextDraw: formatNextDraw(result.next_draw),
      prize: (Number(result.prize_amount) / 100).toFixed(0),
      numbers: result.numbers,
      extraNumbers: result.extra_numbers,
    };
  }) || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container py-4 px-4 sm:px-6 lg:px-8">
        <header className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Wyniki Lotto
          </h1>
          <p className="text-gray-600 text-sm max-w-2xl mx-auto">
            Sprawdź najnowsze wyniki wszystkich gier LOTTO. Aktualizowane na
            bieżąco wyniki, statystyki i informacje o najbliższych losowaniach.
          </p>
        </header>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {games.map((game) => (
            <div
              key={game.title}
              className={`transform transition-all duration-500 ${
                isLoading
                  ? "opacity-0 translate-y-4"
                  : "opacity-100 translate-y-0"
              }`}
              style={{
                transitionDelay: `${games.indexOf(game) * 150}ms`,
              }}
            >
              <GameCard {...game} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Index;

