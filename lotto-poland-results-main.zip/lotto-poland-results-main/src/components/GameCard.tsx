
import { Clock, Euro } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface GameCardProps {
  title: string;
  description: string;
  nextDraw: string;
  price: string;
  prize: string;
  drawTimes: string;
  numbers: number[];
  extraNumbers?: number[];
}

export const GameCard = ({
  title,
  description,
  nextDraw,
  price,
  prize,
  drawTimes,
  numbers,
  extraNumbers,
}: GameCardProps) => {
  return (
    <Card className="w-full transition-all duration-300 hover:shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold">{title}</CardTitle>
          <span className="text-sm text-gray-500">
            <Clock className="inline mr-1 h-4 w-4" />
            {drawTimes}
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-gray-600 mb-4">{description}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {numbers.map((number, index) => (
            <div
              key={`${number}-${index}`}
              className="w-8 h-8 rounded-full bg-lotto-blue text-white flex items-center justify-center text-sm font-semibold"
            >
              {number}
            </div>
          ))}
          {extraNumbers && extraNumbers.length > 0 && (
            <>
              <div className="w-8 h-8 flex items-center justify-center">+</div>
              {extraNumbers.map((number, index) => (
                <div
                  key={`extra-${number}-${index}`}
                  className="w-8 h-8 rounded-full bg-yellow-500 text-white flex items-center justify-center text-sm font-semibold"
                >
                  {number}
                </div>
              ))}
            </>
          )}
        </div>
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <Euro className="h-4 w-4 mr-1 text-lotto-blue" />
            <span className="text-sm text-gray-600">Cena: {price}</span>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-500">Następne losowanie:</div>
            <div className="font-semibold">{nextDraw}</div>
          </div>
        </div>
        <div className="flex flex-col gap-4">
          <div className="text-right">
            <div className="text-2xl font-bold text-lotto-blue">{prize} zł</div>
            <div className="text-sm text-gray-500">do wygrania</div>
          </div>
          <Button className="w-full bg-lotto-blue hover:bg-blue-600 transition-colors">
            Zagraj online
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
